return require("telescope").register_extension {
  -- setup = function(ext_config, config)
  --   -- access extension config and user config
  -- end,
  exports = {
    -- This key must be used when accessing the functions after
    -- loading the extension.
    make_md_file_link = require("telescope_md_file_links").make_md_file_link,
    setup = require("telescope_md_file_links").setup,
  },
}
